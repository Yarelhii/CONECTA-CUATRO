let songs = [
    {
        name: 'INTRO PERSONA',
        path: 'music/bts intro persona.mp3',
        artist: 'BTS',
        cover: 'img/persona.jpg'
    },
    {
        name: 'HOME',
        path: 'music/bts home.mp3',
        artist: 'BTS',
        cover: 'img/persona.jpg'
    },
    {
        name: 'DIONYSUS',
        path: 'musics/bts dionysus.mp3',
        artist: 'BTS',
        cover: 'img/persona.jpg'
    },

    {
        name: 'JAMAIS VU',
        path: 'music/bts jamais vu.mp3',
        artist: 'BTS',
        cover: 'img/persona.jpg'
    },
    {
        name: '작은 것들을 위한 시 ',
        path: 'music/bts 작은 것들을 위한 시 boy with luv feat halsey.mp3',
        artist: 'BTS',
        cover: 'img/persona.jpg'
    },
    {
        name: '소우주 MICROKOSMOS',
        path: 'music/bts 소우주 mikrokosmos.mp3',
        artist: 'BTS',
        cover: 'img/persona.jpg'
    },
    {
        name: 'MAKE IT RIGHT',
        path: 'music/bts make it right.mp3',
        artist: 'BTS',
        cover: 'img/persona.jpg'
    },

]